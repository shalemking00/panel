import logo from './logo.svg';
import './App.css';

import 'bootstrap/dist/css/bootstrap.css'
import Navigationbar from './components/Navigationbar';
import Login from './components/Login';
import Register from './components/Register';
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Home from './components/Home';
import Movies from './components/Movies';
import { useState } from 'react';
import Booking from './components/Booking';

function App() {
  const [loginStatus, setLoginStatus] = useState(false)
  const[movie,setMoive]=useState({})

  const setLoginStatusfunc=(data)=>{
    console.log(data)
    setLoginStatus(data)

  }

  const getMovie=(movie)=>{
    console.log(movie)
    setMoive(movie)

  }

  return (
    <div className="App">
      
      <BrowserRouter>
        <Navigationbar status={loginStatus}/>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/login' element={<Login status={setLoginStatusfunc}/>}/>
          <Route path='/register' element={<Register/>}/>
          <Route path='/movies'  element={<Movies/>} />
          <Route path='/book' element={<Booking movie={getMovie}/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
