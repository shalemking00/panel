import React from 'react'
import './Seat.css'
import { useState } from 'react'


const Seat = (props) => {
    const seats=[]

    const handleSeatSelection=(e)=>{
        e.preventDefault();
        seats.push(e.target.value)
        console.log(seats)
    }


  return (
    <div className='container body'>
        <div className='screen'>
            <div className='row'>
            <input class="form-check-input" type="checkbox" value="A1" />
            <input class="form-check-input" type="checkbox" value="A2" ></input>
            <input class="form-check-input" type="checkbox" value="A3" ></input>
            <input class="form-check-input" type="checkbox" value="A4" ></input>
            <input class="form-check-input" type="checkbox" value="A5" ></input>
            <input class="form-check-input" type="checkbox" value="A6" ></input>
            <input class="form-check-input" type="checkbox" value="A7" ></input>
            <input class="form-check-input" type="checkbox" value="A8" ></input>
            <input class="form-check-input" type="checkbox" value="A9" ></input>
            <input class="form-check-input" type="checkbox" value="A10" ></input>  
            </div>
            <div className='row'>
            <input class="form-check-input" type="checkbox" value="B1" />
            <input class="form-check-input" type="checkbox" value="B2" ></input>
            <input class="form-check-input" type="checkbox" value="B3" ></input>
            <input class="form-check-input" type="checkbox" value="B4" ></input>
            <input class="form-check-input" type="checkbox" value="B5" ></input>
            <input class="form-check-input" type="checkbox" value="B6" ></input>
            <input class="form-check-input" type="checkbox" value="B7" ></input>
            <input class="form-check-input" type="checkbox" value="B8" ></input>
            <input class="form-check-input" type="checkbox" value="B9" ></input>
            <input class="form-check-input" type="checkbox" value="B10" ></input>
            </div>
            <div className='row'>
            <input class="form-check-input" type="checkbox" value="C1" />
            <input class="form-check-input" type="checkbox" value="C2" ></input>
            <input class="form-check-input" type="checkbox" value="C3" ></input>
            <input class="form-check-input" type="checkbox" value="C4" ></input>
            <input class="form-check-input" type="checkbox" value="C5" ></input>
            <input class="form-check-input" type="checkbox" value="C6" ></input>
            <input class="form-check-input" type="checkbox" value="C7" ></input>
            <input class="form-check-input" type="checkbox" value="C8" ></input>
            <input class="form-check-input" type="checkbox" value="C9" ></input>
            <input class="form-check-input" type="checkbox" value="C10" ></input>
            </div>
            <div className='row'>
            <input class="form-check-input" type="checkbox" value="D1" />
            <input class="form-check-input" type="checkbox" value="D2" ></input>
            <input class="form-check-input" type="checkbox" value="D3" ></input>
            <input class="form-check-input" type="checkbox" value="D4" ></input>
            <input class="form-check-input" type="checkbox" value="D5" ></input>
            <input class="form-check-input" type="checkbox" value="D6" ></input>
            <input class="form-check-input" type="checkbox" value="D7" ></input>
            <input class="form-check-input" type="checkbox" value="D8" ></input>
            <input class="form-check-input" type="checkbox" value="D9" ></input>
            <input class="form-check-input" type="checkbox" value="D10" ></input>
            </div>
            <div className='row'>
            <input class="form-check-input" type="checkbox" value="E1" />
            <input class="form-check-input" type="checkbox" value="E2" ></input>
            <input class="form-check-input" type="checkbox" value="E3" ></input>
            <input class="form-check-input" type="checkbox" value="E4" ></input>
            <input class="form-check-input" type="checkbox" value="E5" ></input>
            <input class="form-check-input" type="checkbox" value="E6" ></input>
            <input class="form-check-input" type="checkbox" value="E7" ></input>
            <input class="form-check-input" type="checkbox" value="E8" ></input>
            <input class="form-check-input" type="checkbox" value="E9" ></input>
            <input class="form-check-input" type="checkbox" value="E10" ></input>
            </div>
        </div>
    </div>
  )
}

export default Seat