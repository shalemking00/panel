import React from 'react'
import { useState,useEffect } from 'react'
import axios from 'axios'
import Card from './Card'

const Movies = () => {
    const [movies,setMovies]=useState(null)
    const api="http://localhost:8080/api/v1.0/moviebooking"

    const token=localStorage.getItem('token')

    const authAxios=axios.create({
        baseURL:api,
        headers:{
            Authorization:`Bearer ${token}`
        }
    })

    const getData=async ()=>{
        await authAxios.get(`${api}/all`).then((res)=>{
            console.log(res)
            setMovies(res.data)
            console.log(movies)
        }).catch((e)=>{
            console.log(e)
        })

    }

    useEffect(()=>{
      getData()
    }, [])
    


  return (
    <div className=''>
        <div className='container bg-dark '>
        <div className='row mt-5 p-5'>
        {movies && 
            movies.map((movie)=>{
                return(
                    <div className='col col-lg-4 col-md-6 mb-5'>
                    <Card id={movie._id} status={movie.ticketsStatus} theatre={movie.theatreName} image={movie.poster} title={movie.movieName} ticketsAvailable={movie.noOfTicketsAvailable}/>
                    </div>
                )
            })
        }


        </div>
    </div>
    </div>
  )
}

export default Movies