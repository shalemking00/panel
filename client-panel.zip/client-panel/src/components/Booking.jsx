import React, { useState,useEffect } from 'react'
import { Navigate, useLocation, useNavigate } from 'react-router-dom'
import axios from 'axios'
import Multiselect from 'multiselect-react-dropdown';

const Booking = () => {
    const location=useLocation()
    console.log(location.state.movie)
    const navigate=useNavigate()

    const[seats,setSeats]=useState([])
    const noOfSeatsAvailable=[]
    if(location.state.movie!==null){
        for(var i=1;i<=location.state.movie.ticketsAvailable;i++){
            noOfSeatsAvailable.push(i.toString())
        }
    }

    const[selectedSeats,setSelectedSeats]=useState([])
    const[seatNumber,setSeatNumber]=useState([])


    const api="http://localhost:8080/api/v1.0/moviebooking"

        const token=localStorage.getItem('token')
        const username=localStorage.getItem('username')

        const authAxios=axios.create({
            baseURL:api,
            headers:{
                Authorization:`Bearer ${token}`
            }
        })

    const payload={movieName:"",theatreName:"",noOfTickets:"",loginId:"",seatNumber:[]}

    const handleBook=async()=>{
        if(localStorage.getItem('role')==="ROLE_USER"){

            payload.movieName=location.state.movie.title
            payload.theatreName=location.state.movie.theatre
            payload.noOfTickets=selectedSeats.length
            payload.loginId=localStorage.getItem('username')
            payload.seatNumber=seatNumber
    
            console.log(payload)
            
            await authAxios.post(`${api}/${location.state.movie.title}/add`,payload).then((res)=>{
                console.log(res)
                alert(res.data)
                navigate("/movies")
            }).catch((e)=>{
                alert(e.message)
                console.log(e)
            })

        }else{
            alert("Please login as USER")
        }
       
        
    }




  return (
    <>
        <div className='container mt-5 d-flex justify-content-evenly'>
        <div>
            <img style={{width:"200px",height:"200px"}} src={location.state.movie.image} alt='movie poster'/>
        </div>
        <div>
            <p>Title:{location.state.movie.title}</p>
            <p>TheatreName:{location.state.movie.theatre}</p><br />
            <p>Tickets Available:{location.state.movie.ticketsAvailable}</p>
            <p>Ticket Status:{location.state.movie.status}</p>
        </div>
        <div>
            <Multiselect 
            isObject={false} 
            options={noOfSeatsAvailable} 
            selectedValues={(e)=> setSeatNumber(e)} 
            onSelect={(e)=>{
                setSelectedSeats(e)
                return console.log(selectedSeats)
            }} 
            onRemove={(e)=>{
                setSelectedSeats(e)
                setSeatNumber(e)
                return console.log(selectedSeats,seatNumber)
            }}  />
        </div>

    </div>
    <div>
    <button type="button" class="btn btn-primary" onClick={handleBook}>Book</button>
    </div>
    
    </>
  )
}

export default Booking