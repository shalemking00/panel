import React, { useEffect } from "react";
import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./Register.css"

const Register = () => {
  const [username, setUsername] = useState("")
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const[roles,setRoles]=useState([])
  const [email, setEmail] = useState("")
  const [contactNumber, setContactNumber] = useState("")
  const [password, setPassword] = useState("")
  const navigate = useNavigate();

  const requestBody={loginId:"",roles:[],firstName:"",lastName:"",email:"",contactNumber:"",password:""}

  

  const handleSubmit=(e)=>{
    e.preventDefault();
    requestBody.loginId=username
    requestBody.firstName=firstName
    requestBody.lastName=lastName
    requestBody.roles.push(roles)
    requestBody.email=email
    requestBody.contactNumber=contactNumber
    requestBody.password=password

    console.log(requestBody)

    axios.post("http://localhost:8080/api/v1.0/moviebooking/register",requestBody).then((res)=>{
      console.log(res)
      if(res.status===200){
        alert(res.data.message)
        navigate("/login")
        
      }
    }).catch((e)=>{
      console.log(e)
      alert(e.response.data.message)
    })

  }
  return (
    <div className="container mb-5 bg-dark form-inputs">
      <h4 className="mt-5">Register</h4>
      <form onSubmit={handleSubmit} className="mb-5">
        <div className="form-floating mb-3">
          <input
            type="text"
            className="form-control"
            id="exampleInputusername"
            aria-describedby="emailHelp"
            value={username}
            onChange={(e)=>setUsername(e.target.value)}
          />
          <label for="exampleInputusername" className="form-label">
            username
          </label>
        </div>
        <div className=" form-floating mb-3">
          <input
            type="text"
            className="form-control"
            id="exampleInputfirstName"
            aria-describedby="emailHelp"
            value={firstName}
            onChange={(e)=>setFirstName(e.target.value)}
          />
          <label for="exampleInputfirstName" className="form-label">
            First Name
          </label>
          {/* <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div> */}
        </div>
        <div className=" form-floating mb-3">
          
          <input
            type="text"
            className="form-control"
            id="exampleInputlastName"
            aria-describedby="emailHelp"
            value={lastName}
            onChange={(e)=>setLastName(e.target.value)}
          />
          <label for="exampleInputlastName" className="form-label">
            Last Name
          </label>
          {/* <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div> */}
        </div>

        <div className="form-floating  mb-3">
          
          <select id="roles" className="roles" value={roles} onChange={(e)=>setRoles(e.target.value)}>
        <option value="admin">Admin</option>
        <option value="user">User</option>
        <label for="=roles">
            Role
        </label>
        
      </select>
          
        </div>

        <div className="form-floating mb-3">
          <input
            type="email"
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            value={email}
            onChange={(e)=>setEmail(e.target.value)}
          />
          <label for="exampleInputEmail1" className="form-label">
            Email address
          </label>
          {/* <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div> */}
        </div>

        <div className=" form-floating mb-3">
          
          <input
            type="number"
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            value={contactNumber}
            onChange={(e)=>setContactNumber(e.target.value)}
          />
          <label for="mobile" className="form-label">
            Mobile
          </label>
          {/* <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div> */}
        </div>
        <div className="form-floating mb-3">
          <input
            type="password"
            className="form-control"
            id="exampleInputPassword1"
            value={password}
            onChange={(e)=>setPassword(e.target.value)}
          />
          <label for="exampleInputPassword1" className="form-label">
            Password
          </label>
        </div>

        <button type="submit" className="btn mb-5 btn-primary">
          Register
        </button>
      </form>
    </div>
  );
};

export default Register;
