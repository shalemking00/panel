describe('Navbar component', () => {
  beforeEach(()=>{
    cy.visit('http://localhost:3000')
  });

  it("renders navbar items correctly",()=>{
    cy.get('.nav-item').eq(0).should('contain','Movies')
    cy.get('.nav-item').eq(1).should('contain','Login')
  });

  it("navigates to the correct page",()=>{
    cy.get('.nav-item').eq(0).click()
    cy.url().should('include','/movies')
  })
  
})