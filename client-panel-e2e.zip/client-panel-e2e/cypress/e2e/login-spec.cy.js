
describe('Login', () => {
  beforeEach(()=>{
    cy.visit("http://localhost:3000/login")

  })

  it("displays login form",()=>{
    cy.get('form').should('exist')
    cy.get('input[name="username"]').should('exist')
    cy.get('input[name="password"]').should('exist')
  })

  it("logs in succesfully with valid credentials",()=>{
    cy.get('input[name="username"]').type('kiran')
    cy.get('input[name="password"]').type('123456')
    cy.get('button[type="submit"]').click()

    // cy.intercept('http://localhost:8080/api/v1.0/moviebooking/login',{method:'POST'},(req)=>{
    //   req.reply({
    //     status:200,
    //     body:{
    //       "_id": {
    //         "timestamp": 1687235916,
    //         "date": "2023-06-20T04:38:36.000+00:00"
    //     },
    //     "email": "shalem712@gmail.com",
    //     "roles": [
    //         "ROLE_ADMIN"
    //     ],
    //     "tokenType": "Bearer",
    //     "accessToken": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJzaGFsZW0iLCJpYXQiOjE2ODc1NzQ1MDYsImV4cCI6MTY4NzY2MDkwNn0.Gn31Fnh2iTn0K7vMLa35HZsqiQqCLkyizC22Cx2ZY_qDrjq4tE_qnp2aOcDohtaJ2V9EyaGWkM3xOei3HtKlUQ",
    //     "username": "shalem"
    //     }
    //   })
    // }).as('loginRequest')
    
    // cy.wait('@loginRequest').then((interception)=>{
    //   console.log(interception.response)
    //   const {accessToken}=interception.response.body.accessToken
    //   cy.window().then((win)=>{
    //     win.localStorage.setItem('token',accessToken)
    //   })
    // })

    // cy.window().then((win)=>{
    //   const token=win.localStorage.getItem('token')
    //   expect(token).to.exist;
    // })

    cy.url().should('include','/')

  })
  
})