describe('movie component tests', () => {

  beforeEach(()=>{
    cy.visit("http://localhost:3000/home")

  })

  it("loads data from url correctly",()=>{
    cy.fixture('movies.json').then((expectedData)=>{
      cy.intercept('GET',"http://localhost:8080/api/v1.0/moviebooking/all",{
        fixture:'movies.json',
      }).as('getData');

      cy.visit('http://localhost:3000/movies');
      cy.wait('@getData').then((interception)=>{
        expect(interception.request.url).to.equal("http://localhost:8080/api/v1.0/moviebooking/all")
        expect(interception.response.body).to.deep.equal(expectedData)
        expect(interception.response.statusCode).to.equal(200)
      })
    })
  })

  it('renders child component',()=>{
    cy.get('.parent').find('.child').should('exist')
  })
  
})