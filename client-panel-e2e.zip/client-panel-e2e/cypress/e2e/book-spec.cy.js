describe('Booking page  spec', () => {

  beforeEach(()=>{
    cy.visit("http://localhost:3000/book")

  })

  


  
})