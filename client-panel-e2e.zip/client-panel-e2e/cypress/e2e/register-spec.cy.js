describe('Register ', () => {

  beforeEach(()=>{
    cy.visit("http://localhost:3000/register")

  })

  it("displays Register form",()=>{
    cy.get('form').should('exist')
    cy.get('input[name="username"]').should('exist')
    cy.get('input[name="firstname"]').should('exist')
    cy.get('input[name="lastname"]').should('exist')
    cy.get('input[name="email"]').should('exist')
    cy.get('select[name="roles"]').should('exist')
    cy.get('input[name="contactNumber"]').should('exist')
    cy.get('input[name="password"]').should('exist')
  })

  it("registers  succesfully with valid credentials",()=>{
    cy.get('input[name="username"]').type('king')
    cy.get('input[name="firstname"]').type('Raj')
    cy.get('input[name="lastname"]').type('kaneti')
    cy.get('input[name="email"]').type('king@gmail.com')
    cy.get('input[name="password"]').type('123456')
    cy.get('input[name="contactNumber"]').type('1234567890')
    cy.get('select').select('user')
    cy.get('select').select('user')
    cy.get('select').should('have.value','user')
  })




})