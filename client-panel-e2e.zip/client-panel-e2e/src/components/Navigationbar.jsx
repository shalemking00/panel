import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import './Nvaigation.css';


function Navigationbar({status}) {

  const navigate=useNavigate()

  const[isLogged,setIsLogged]=useState(false)

  const[search,setSearch]=useState("")
  const api="http://localhost:8080/api/v1.0/moviebooking"
  const token=isLogged?localStorage.getItem('token'):null

  const setLoginAndLogout=(status)=>{
    setIsLogged(status)
  }

  const logout=()=>{
    localStorage.clear()
    navigate("/login")
  }

  const authAxios=axios.create({
    baseURL:api,
    headers:{
        Authorization:`Bearer ${token}`
    }
})

  const handleSearch=async(e)=>{
    e.preventDefault()
    await authAxios.get(`${api}/movies/search/${search}`).then((res)=>{
      console.log(res.data[0])
      navigate("/search",{state:{searchedItem:res.data[0]}})
  }).catch((e)=>{
    alert(e)
    console.log(e)
  })

  }

  return (
    <nav class="navbar mb-0  navbar-expand-lg navbar-light bg-dark" >
  <div class="container-fluid ">
    <a class="navbar-brand nav-content" href="/home">Book N Crook</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse  navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link nav-content" aria-current="page" href="/movies">Movies</a>
        </li>
        <li class="nav-item nav-content">
          {isLogged ? <a class="nav-link nav-content" style={{cursor:"pointer"}} onClick={logout}>{status?"Logout":"Login"}</a> : <a class="nav-link nav-content" style={{cursor:"pointer"}} onClick={setLoginAndLogout}>{status?"Logout":"Login"}</a>}
        </li>
        {isLogged && <li class="nav-item  dropdown">
          <a class="nav-link nav-content dropdown-toggle " href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="/reset">Change Password</a></li>
          </ul>
        </li>}
      </ul>
      
      {isLogged && <form class="d-flex" onSubmit={handleSearch}>
        <input class="form-control me-2" value={search} type="search" placeholder="Search" onChange={(e)=>setSearch(e.target.value)} aria-label="Search"/>
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>}
    </div>
  </div>
</nav>
    
  );
}

export default Navigationbar;