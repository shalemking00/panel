import React, { useState,useEffect } from 'react'
import axios from 'axios'
import HomeCard from './HomeCard';

const Home = () => {

  const [movies,setMovies]=useState([]);

  useEffect(() => {

     axios.get("http://localhost:8080/api/v1.0/moviebooking/all").then((res)=>{
        console.log(res);
        setMovies(res.data)
        console.log(movies)
    }).catch((e)=>{
      console.log(e)
    });
  }, [])
  


  return (
    <div className='parent'>
        <div className='container bg-dark '>
        <div className='row mt-5 p-5'>
        {movies && 
            movies.map((movie)=>{
                return(
                    <div className='col child col-lg-4 col-md-6 mb-5'>
                    <HomeCard id={movie._id} status={movie.ticketsStatus} theatre={movie.theatreName} image={movie.poster} title={movie.movieName} ticketsAvailable={movie.noOfTicketsAvailable}/>
                    </div>
                )
            })
        }
        </div>
    </div>
    </div>
  )
}

export default Home