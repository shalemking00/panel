import React from 'react'
import { useLocation } from 'react-router-dom'
import Card from './Card'
import './Search.css'

const Search = () => {
const location=useLocation()
console.log(location.state.movie)

  return (
    <div className='container mt-5'>
        <Card id={location.state.searchedItem._id} status={location.state.searchedItem.ticketsStatus} theatre={location.state.searchedItem.theatreName} image={location.state.searchedItem.poster} title={location.state.searchedItem.movieName} role={localStorage.getItem('role')} ticketsAvailable={location.state.searchedItem.noOfTicketsAvailable}/>
    </div>
  )
}

export default Search