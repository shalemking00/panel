import axios from "axios";
import React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import './Login.css'

const Login = (props) => {

  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [login,setLogin] = useState("")
  const loginRequest={loginId:"",password:""}

  const navigate =useNavigate();

  const handleSubmit=async(e)=>{
    e.preventDefault();
    console.log(username,password)
    loginRequest.loginId=username
    loginRequest.password=password
    await axios.post("http://localhost:8080/api/v1.0/moviebooking/login",loginRequest).then((res)=>{
      console.log(login)
      console.log(res)
      if(res.status===200){
        setLogin("logged")
        localStorage.setItem('token',res.data.accessToken)
        localStorage.setItem('role',res.data.roles)
        localStorage.setItem('username',res.data.username)
        // console.log(alert())
        // alert("Successfully logged in")
        props.status(true)
        navigate("/movies")
      }else{
        props.status(false)
        navigate("/login")
      }
    }).catch((e)=>{
      console.log(e)
      alert(e)
    })

  }

  return (
    <div className="container mt-5 form-inputs">
      <h4 className="mb-3">Login</h4>
      <form onSubmit={handleSubmit}>
        <div className="form-floating mb-3">
          <input
            type="text"
            className="form-control"
            name="username"
            id="floatingInput"
            aria-describedby="emailHelp"
            value={username}
            onChange={(e)=>setUsername(e.target.value)}
          />
          <label for="floatingInput" className="">
            username
          </label>
        </div>
        <div className=" form-floating mb-3">
          <input
            type="password"
            className="form-control"
            id="exampleInputPassword1"
            name="password"
            value={password}
            onChange={(e)=>setPassword(e.target.value)}
          />
          <label for="exampleInputPassword1" className="">
            Password
          </label>
        </div>
        <button type="submit" className="btn btn-primary">
          Login
        </button>
        <div id="emailHelp" className="form-text">
           New User?<a href="/register">Register here</a> 
          </div>
      </form>
    </div>
  );
};

export default Login;
