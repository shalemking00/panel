import React, { useState, useEffect } from 'react'
import { Navigate, useLocation, useNavigate } from 'react-router-dom'
import axios from 'axios'
import './Booking.css'

const Booking = () => {
    const location = useLocation()
    //console.log(location.state.movie)
    const navigate = useNavigate()

    //    const getSelectedSeats=(data)=>{
    //         console.log(data)
    //    }

    //const [selectedSeats, setSelectedSeats] = useState(" ")
    const [seatNumber,setSeatNumber]= useState([])

    const api = "http://localhost:8080/api/v1.0/moviebooking"

    const token = localStorage.getItem('token')
    const username = localStorage.getItem('username')

    const authAxios = axios.create({
        baseURL: api,
        headers: {
            Authorization: `Bearer ${token}`
        }
    })

    const payload = { movieName: "", theatreName: "", noOfTickets: "", loginId: "", seatNumber: [] }

    const addSeats = () => {
        const value=document.getElementById('box').value
        const newArray=[...seatNumber,value]
        setSeatNumber(newArray)
        document.getElementById('box').value=''
       
        // setSeatNumber([...seatNumber,selectedSeats])
        // setSelectedSeats('')
         console.log(seatNumber)
    }

    const removeSeats=()=>{
        setSeatNumber([])
    }

    const handleBook = async () => {
        if (localStorage.getItem('role') === "ROLE_USER") {

            payload.movieName = location.state.movie.title
            payload.theatreName = location.state.movie.theatre
            payload.noOfTickets = seatNumber.length
            payload.loginId = localStorage.getItem('username')
            payload.seatNumber = seatNumber

            console.log(payload)

            await authAxios.post(`${api}/${location.state.movie.title}/add`, payload).then((res) => {
                console.log(res)
                alert(res.data)
                navigate("/movies")
            }).catch((e) => {
                alert(e.message)
                console.log(e)
            })

        } else {
            alert("Please login as USER")
        }


    }

    return (
    <>
            <div className='container parent size border border-5 d-flex bd-highlight gap-3 justify-content-evenly mt-5'>
                <div className='mt-5 img'>
                    <img style={{ width: "100px", height: "100px" }} src={location.state.movie.image} alt='movie poster' />
                </div>
                <div className='mt-5 txt'>
                    <p className='text-start'>Title : {location.state.movie.title}</p>
                    <p className='text-start'>TheatreName : {location.state.movie.theatre}</p>
                    <p className='text-start'>Tickets Available : {location.state.movie.ticketsAvailable}</p>
                    <p className='text-start'>Ticket Status : {location.state.movie.status}</p>
                </div>
               
                        <div class="mt-5 form-check ipfields">
                            <input type="text" className="formcontrol"  id="box" />
                           <p>selected seats:{seatNumber.map((item)=>`${item} `)}</p>
                            <button class="btn btn-primary m-1" onClick={addSeats}>Add</button>
                            <button class="btn btn-sm btn-danger m-3" onClick={removeSeats}>Remove</button>

                        </div>
                        
                        
                
            </div>
            <div>
                <button type="button" class="btn btn-primary" onClick={handleBook}>Book</button>
            </div>
            </>
            )
}

            export default Booking;