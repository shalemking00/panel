import React from 'react'
import './Seat.css'
import { useState } from 'react'


const Seat = (props) => {
  const seatClass=props.isSelected ? 'seat selected' : 'seat'

  return (
    <div className={seatClass} onClick={props.onSelect}>
      {props.number}
    </div>
  )
}

export default Seat