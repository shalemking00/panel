import React from 'react'
import { useLocation } from 'react-router-dom'
import './View.css'

const View = () => {
    const location=useLocation()
    console.log(location.state.booked)
  return (
    <div>
        <h4 className='mt-5'>Booked Tickets</h4>
        <div className='container size border border-5 d-flex justify-content-evenly mt-5'>
            
                <div className='mt-3'>
                    <img style={{ width: "200px", height: "200px" }} src={location.state.image} alt='movie poster' />
                </div>
                <div className='mt-5'>
                    <p className='text-start'>Title : {location.state.booked[0].movieName}</p>
                    <p className='text-start'>TheatreName : {location.state.booked[0].theatreName}</p>
                    <p className='text-start'>No of Tickets Booked : {location.state.booked[0].noOfTickets}</p>
                    <p className='text-start'>seat Numbers : {location.state.booked[0].seatNumber}</p>
                </div>
        </div>
    </div>
  )
}

export default View