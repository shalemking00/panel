import React, { useState } from 'react'
import Seat from './Seat'
import './Seat.css'

const SeatMap = ({numRows,numCols,getSeatsbooked}) => {
    const [selectedSeats,setSelectedSeats]=useState([])

    const handleSeatSelect=(row,column)=>{
        const seat=`${row}-${column}`
        const isSelected=selectedSeats.includes(seat);
        if(isSelected){
            setSelectedSeats(selectedSeats.filter((s)=>s !== seat))
        }else{
            setSelectedSeats([...selectedSeats,seat])
        }
        getSeatsbooked(selectedSeats);
    }


  return (
    <div className='seat-map '>
        <h2>Select your seats</h2>
        <div className='grid d-flex'>
            {[...Array(numRows)].map((_,row)=>(
                <div key={row} className="row">
                    {[...Array(numCols)].map((_,col)=>(
                        <Seat
                            key={col}
                            number={`${row + 1}-${col + 1}`}
                            isSelected={selectedSeats.includes(`${row}-${col}`)}
                            onSelect={()=>handleSeatSelect(row,col)}
                        />
                    ))}

                </div>
            ))}
        </div>

    </div>
  )
}

export default SeatMap