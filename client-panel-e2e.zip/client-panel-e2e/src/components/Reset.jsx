import React, { useState } from 'react'
import './reset.css'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const Reset = () => {
    const[newPassword,setNewPassword]=useState("")
    const navigate=useNavigate()

    const token=localStorage.getItem('token')
    const loginId=localStorage.getItem('username')
    const api="http://localhost:8080/api/v1.0/moviebooking"


    const authAxios=axios.create({
        baseURL:api,
        headers:{
            Authorization:`Bearer ${token}`
        }
    })

    const payload={password:newPassword}

    const handleSubmit=async(e)=>{
        e.preventDefault();
        authAxios.put(`${api}/${loginId}/forgot`,payload).then((res)=>{
            console.log(res);
            alert(res.data)
            navigate("/Movies")
        }).catch((e)=>{
            alert(e)
        })
    }

    return (
        <div className='container form-inputs mt-5'>
            <h4 className='mb-3'>Reset Password</h4>
            <form onSubmit={handleSubmit}>
                <div class="form-floating mb-3">
                    <input type="password" value={newPassword} onChange={(e)=>setNewPassword(e.target.value)} className="form-control " id="exampleInputPassword1"/>
                    <label for="exampleInputPassword1" className="form-label">Enter New Password</label>
                </div>
                <button type="submit" className="btn btn-sm btn-primary">Submit</button>
            </form>
        </div>
    )
}

export default Reset