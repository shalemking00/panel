import React from 'react'

const HomeCard = (props) => {

  return (
    <div className="card" style={{width: "18rem"}}>
      <img src={props.image} style={{height:"200px",width:"287px"}} className="card-img-top" alt="movie image" />
      <div className="card-body">
        <h5 className="card-title">{props.title}</h5>
        <p className="card-text">
            {props.theatre}
        </p>
      </div>
    </div>
  )
}

export default HomeCard