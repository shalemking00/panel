import React from "react";
import { useNavigate } from "react-router-dom";
import Booking from "./Booking";
import axios from "axios";

const Card = (props) => {

  const navigate=useNavigate();
  const api="http://localhost:8080/api/v1.0/moviebooking"
  const token=localStorage.getItem('token')

  const handlebook=()=>{
    navigate("/book",{state:{movie:props}})
  }

  const authAxios=axios.create({
    baseURL:api,
    headers:{
        Authorization:`Bearer ${token}`
    }
})

  const handleView =()=>{
    authAxios.get(`${api}/getallbookedtickets/${props.title}`).then((res)=>{
      console.log(res)
      if(res.data.length!==0){
        navigate("/view",{state:{booked:res.data,image:props.image}})
      }else{
        alert("No tickets Booked")
      }
      //navigate("/view",{state:{view:res.data}})
    }).catch((e)=>{
      console.log(e)
      alert(e);
    })
    console.log("view page")
  }

  return (
    <div className="card" style={{width: "18rem"}}>
      <img src={props.image} style={{height:"200px",width:"287px"}} className="card-img-top" alt="movie image" />
      <div className="card-body">
        <h5 className="card-title">{props.title}</h5>
        <p className="card-text">
            {props.theatre}
        </p>
        {props.role==="ROLE_ADMIN" ? <a  className="btn btn-primary" onClick={handleView}>
          View Tickets
        </a>:<a  className="btn btn-primary" onClick={handlebook}>
          Book
        </a>}
      </div>
    </div>
  );
};

export default Card;
