package com.moviebookingapp.models;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
